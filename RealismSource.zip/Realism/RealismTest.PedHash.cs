// RealismTest.PedHash
namespace RealismTest
{
    public enum PedHash : uint
    {
        Michael = 225514697u,
        Franklin = 2602752943u,
        Trevor = 2608926626u
    }
}